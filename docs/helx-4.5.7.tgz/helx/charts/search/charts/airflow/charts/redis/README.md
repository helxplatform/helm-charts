# redis

> **:exclamation: This Helm Chart is deprecated!**

![Version: 10.5.7](https://img.shields.io/badge/Version-10.5.7-informational?style=flat-square) ![AppVersion: 5.0.7](https://img.shields.io/badge/AppVersion-5.0.7-informational?style=flat-square)

DEPRECATED Open source, advanced key-value store. It is often referred to as a data structure server since keys can contain strings, hashes, lists, sets and sorted sets.

**Homepage:** <http://redis.io/>

## Source Code

* <https://github.com/bitnami/bitnami-docker-redis>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cluster.enabled | bool | `true` |  |
| cluster.slaveCount | int | `2` |  |
| clusterDomain | string | `"cluster.local"` |  |
| configmap | string | `"# Enable AOF https://redis.io/topics/persistence#append-only-file\nappendonly yes\n# Disable RDB persistence, AOF persistence already enabled.\nsave \"\""` |  |
| global.redis | object | `{}` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.registry | string | `"docker.io"` |  |
| image.repository | string | `"bitnami/redis"` |  |
| image.tag | string | `"5.0.7-debian-10-r32"` |  |
| master.affinity | object | `{}` |  |
| master.command | string | `"/run.sh"` |  |
| master.configmap | string | `nil` |  |
| master.disableCommands[0] | string | `"FLUSHDB"` |  |
| master.disableCommands[1] | string | `"FLUSHALL"` |  |
| master.extraFlags | list | `[]` |  |
| master.livenessProbe.enabled | bool | `true` |  |
| master.livenessProbe.failureThreshold | int | `5` |  |
| master.livenessProbe.initialDelaySeconds | int | `5` |  |
| master.livenessProbe.periodSeconds | int | `5` |  |
| master.livenessProbe.successThreshold | int | `1` |  |
| master.livenessProbe.timeoutSeconds | int | `5` |  |
| master.persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| master.persistence.enabled | bool | `true` |  |
| master.persistence.matchExpressions | object | `{}` |  |
| master.persistence.matchLabels | object | `{}` |  |
| master.persistence.path | string | `"/data"` |  |
| master.persistence.size | string | `"8Gi"` |  |
| master.persistence.subPath | string | `""` |  |
| master.podAnnotations | object | `{}` |  |
| master.podLabels | object | `{}` |  |
| master.readinessProbe.enabled | bool | `true` |  |
| master.readinessProbe.failureThreshold | int | `5` |  |
| master.readinessProbe.initialDelaySeconds | int | `5` |  |
| master.readinessProbe.periodSeconds | int | `5` |  |
| master.readinessProbe.successThreshold | int | `1` |  |
| master.readinessProbe.timeoutSeconds | int | `1` |  |
| master.service.annotations | object | `{}` |  |
| master.service.labels | object | `{}` |  |
| master.service.loadBalancerIP | string | `nil` |  |
| master.service.port | int | `6379` |  |
| master.service.type | string | `"ClusterIP"` |  |
| master.statefulset.updateStrategy | string | `"RollingUpdate"` |  |
| metrics.enabled | bool | `false` |  |
| metrics.image.pullPolicy | string | `"IfNotPresent"` |  |
| metrics.image.registry | string | `"docker.io"` |  |
| metrics.image.repository | string | `"bitnami/redis-exporter"` |  |
| metrics.image.tag | string | `"1.4.0-debian-10-r3"` |  |
| metrics.podAnnotations."prometheus.io/port" | string | `"9121"` |  |
| metrics.podAnnotations."prometheus.io/scrape" | string | `"true"` |  |
| metrics.prometheusRule.additionalLabels | object | `{}` |  |
| metrics.prometheusRule.enabled | bool | `false` |  |
| metrics.prometheusRule.namespace | string | `""` |  |
| metrics.prometheusRule.rules | list | `[]` |  |
| metrics.service.annotations | object | `{}` |  |
| metrics.service.labels | object | `{}` |  |
| metrics.service.type | string | `"ClusterIP"` |  |
| metrics.serviceMonitor.enabled | bool | `false` |  |
| metrics.serviceMonitor.selector.prometheus | string | `"kube-prometheus"` |  |
| networkPolicy.enabled | bool | `false` |  |
| networkPolicy.ingressNSMatchLabels | object | `{}` |  |
| networkPolicy.ingressNSPodMatchLabels | object | `{}` |  |
| password | string | `""` |  |
| persistence | object | `{}` |  |
| podSecurityPolicy.create | bool | `false` |  |
| rbac.create | bool | `false` |  |
| rbac.role.rules | list | `[]` |  |
| redisPort | int | `6379` |  |
| securityContext.enabled | bool | `true` |  |
| securityContext.fsGroup | int | `1001` |  |
| securityContext.runAsUser | int | `1001` |  |
| sentinel.configmap | string | `nil` |  |
| sentinel.downAfterMilliseconds | int | `60000` |  |
| sentinel.enabled | bool | `false` |  |
| sentinel.failoverTimeout | int | `18000` |  |
| sentinel.image.pullPolicy | string | `"IfNotPresent"` |  |
| sentinel.image.registry | string | `"docker.io"` |  |
| sentinel.image.repository | string | `"bitnami/redis-sentinel"` |  |
| sentinel.image.tag | string | `"5.0.7-debian-10-r27"` |  |
| sentinel.initialCheckTimeout | int | `5` |  |
| sentinel.livenessProbe.enabled | bool | `true` |  |
| sentinel.livenessProbe.failureThreshold | int | `5` |  |
| sentinel.livenessProbe.initialDelaySeconds | int | `5` |  |
| sentinel.livenessProbe.periodSeconds | int | `5` |  |
| sentinel.livenessProbe.successThreshold | int | `1` |  |
| sentinel.livenessProbe.timeoutSeconds | int | `5` |  |
| sentinel.masterSet | string | `"mymaster"` |  |
| sentinel.parallelSyncs | int | `1` |  |
| sentinel.port | int | `26379` |  |
| sentinel.quorum | int | `2` |  |
| sentinel.readinessProbe.enabled | bool | `true` |  |
| sentinel.readinessProbe.failureThreshold | int | `5` |  |
| sentinel.readinessProbe.initialDelaySeconds | int | `5` |  |
| sentinel.readinessProbe.periodSeconds | int | `5` |  |
| sentinel.readinessProbe.successThreshold | int | `1` |  |
| sentinel.readinessProbe.timeoutSeconds | int | `1` |  |
| sentinel.service.annotations | object | `{}` |  |
| sentinel.service.labels | object | `{}` |  |
| sentinel.service.loadBalancerIP | string | `nil` |  |
| sentinel.service.redisPort | int | `6379` |  |
| sentinel.service.sentinelPort | int | `26379` |  |
| sentinel.service.type | string | `"ClusterIP"` |  |
| sentinel.staticID | bool | `false` |  |
| sentinel.usePassword | bool | `true` |  |
| serviceAccount.create | bool | `false` |  |
| serviceAccount.name | string | `nil` |  |
| slave.affinity | object | `{}` |  |
| slave.command | string | `"/run.sh"` |  |
| slave.configmap | string | `nil` |  |
| slave.disableCommands[0] | string | `"FLUSHDB"` |  |
| slave.disableCommands[1] | string | `"FLUSHALL"` |  |
| slave.extraFlags | list | `[]` |  |
| slave.livenessProbe.enabled | bool | `true` |  |
| slave.livenessProbe.failureThreshold | int | `5` |  |
| slave.livenessProbe.initialDelaySeconds | int | `30` |  |
| slave.livenessProbe.periodSeconds | int | `10` |  |
| slave.livenessProbe.successThreshold | int | `1` |  |
| slave.livenessProbe.timeoutSeconds | int | `5` |  |
| slave.persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| slave.persistence.enabled | bool | `true` |  |
| slave.persistence.matchExpressions | object | `{}` |  |
| slave.persistence.matchLabels | object | `{}` |  |
| slave.persistence.path | string | `"/data"` |  |
| slave.persistence.size | string | `"8Gi"` |  |
| slave.persistence.subPath | string | `""` |  |
| slave.podAnnotations | object | `{}` |  |
| slave.podLabels | object | `{}` |  |
| slave.port | int | `6379` |  |
| slave.readinessProbe.enabled | bool | `true` |  |
| slave.readinessProbe.failureThreshold | int | `5` |  |
| slave.readinessProbe.initialDelaySeconds | int | `5` |  |
| slave.readinessProbe.periodSeconds | int | `10` |  |
| slave.readinessProbe.successThreshold | int | `1` |  |
| slave.readinessProbe.timeoutSeconds | int | `10` |  |
| slave.service.annotations | object | `{}` |  |
| slave.service.labels | object | `{}` |  |
| slave.service.loadBalancerIP | string | `nil` |  |
| slave.service.port | int | `6379` |  |
| slave.service.type | string | `"ClusterIP"` |  |
| slave.statefulset.updateStrategy | string | `"RollingUpdate"` |  |
| sysctlImage.command | list | `[]` |  |
| sysctlImage.enabled | bool | `false` |  |
| sysctlImage.mountHostSys | bool | `false` |  |
| sysctlImage.pullPolicy | string | `"Always"` |  |
| sysctlImage.registry | string | `"docker.io"` |  |
| sysctlImage.repository | string | `"bitnami/minideb"` |  |
| sysctlImage.resources | object | `{}` |  |
| sysctlImage.tag | string | `"buster"` |  |
| usePassword | bool | `true` |  |
| usePasswordFile | bool | `false` |  |
| volumePermissions.enabled | bool | `false` |  |
| volumePermissions.image.pullPolicy | string | `"Always"` |  |
| volumePermissions.image.registry | string | `"docker.io"` |  |
| volumePermissions.image.repository | string | `"bitnami/minideb"` |  |
| volumePermissions.image.tag | string | `"buster"` |  |
| volumePermissions.resources | object | `{}` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.11.0](https://github.com/norwoodj/helm-docs/releases/v1.11.0)
